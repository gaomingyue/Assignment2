
import java.io.*;  
	import javax.swing.*;
	import java.awt.event.*;

	public class MainGUI implements ActionListener
	{
	public void run(){
		JFrame  frame =new JFrame();
		JButton bt= new JButton("�鿴��ʦ��Ϣ");
		bt.addActionListener(this);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);		
		frame.setVisible(true);
		frame.getContentPane().add(bt);
		frame.setSize(600, 600);
	}
	
	public void actionPerformed(ActionEvent event)
	{
		String[]i = {};
		Main2014302580133.main(i);
		try 
		{
			Runtime.getRuntime().exec("cmd /c start src/homework.txt");
		} 
		catch (IOException e)
		{
			e.printStackTrace();
		}
		System.exit(0);
	}
	public static void main(String[] arg)
	{
		// TODO Auto-generated method stub
		MainGUI gui = new MainGUI();
		gui.run();
		
		
	}
	}		
